import { useEffect, useMemo, useState } from 'react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import PeriodSelector from './PeriodSelector.jsx';
import MetricSelector from './MetricSelector.jsx';
import { buildFilialDataset } from '../data/mockData.js';
import { buildPeriodSeries } from '../data/periodBuckets.js';
import { buildRealMetricSeries, buildFuncionarioSeries } from '../data/realAggregation.js';
import { useRealFilialData } from '../hooks/useRealFilialData.js';
import { firebaseIsConfigured } from '../config/firebase.js';
import './PerformanceChart.css';

const PIE_COLORS = ['#ff2e9c', '#35e6d8', '#ffcc4d', '#7a2eff', '#33e6a0', '#ff4568'];

const compactFormatter = new Intl.NumberFormat('pt-BR', {
  notation: 'compact',
  maximumFractionDigits: 1,
});

const fullCurrencyFormatter = new Intl.NumberFormat('pt-BR', {
  style: 'currency',
  currency: 'BRL',
});

function buildMetricGroups(funcionarios) {
  return [
    {
      key: 'vendas',
      label: 'Vendas',
      items: [
        { key: 'vendasTotais', label: 'Totais' },
        { key: 'vendasPix', label: 'Pix' },
        { key: 'vendasCartao', label: 'Cartão' },
        { key: 'vendasPromissoria', label: 'Promissória' },
        { key: 'vendasDinheiro', label: 'Dinheiro' },
        { key: 'porFuncionario', label: 'Por funcionário' },
      ],
    },
    {
      key: 'financeiro',
      label: 'Financeiro',
      items: [
        { key: 'gastos', label: 'Gastos' },
        { key: 'lucro', label: 'Lucro' },
      ],
    },
  ];
}

export default function PerformanceChart({ filialId }) {
  const [period, setPeriod] = useState('mes');
  const [customRange, setCustomRange] = useState({ start: '', end: '' });
  const [metricKey, setMetricKey] = useState('vendasTotais');
  const [selectedFuncionarioId, setSelectedFuncionarioId] = useState(null);
  const [chartType, setChartType] = useState('line'); // 'line' | 'pie'

  // Dados reais (Firestore) quando configurado; senão, mock local.
  const real = useRealFilialData(filialId);
  const mock = useMemo(() => buildFilialDataset(filialId), [filialId]);

  const funcionarios = firebaseIsConfigured ? real.funcionarios : mock.funcionarios;
  const metricSeries = useMemo(
    () =>
      firebaseIsConfigured
        ? buildRealMetricSeries(real)
        : mock.metricSeries,
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [
      firebaseIsConfigured,
      mock,
      real.registrosDiarios,
      real.registrosMensaisHistoricos,
      real.gastos,
    ]
  );

  const metricGroups = useMemo(() => buildMetricGroups(funcionarios), [funcionarios]);
  const allItems = useMemo(() => metricGroups.flatMap((g) => g.items), [metricGroups]);
  const activeMetric = allItems.find((i) => i.key === metricKey);
  const isFuncionarioMode = metricKey === 'porFuncionario';

  // Se a filial mudar (ou os funcionários carregarem) e o selecionado não
  // existir mais, cai no primeiro disponível.
  useEffect(() => {
    if (funcionarios.length > 0 && !funcionarios.some((f) => f.id === selectedFuncionarioId)) {
      setSelectedFuncionarioId(funcionarios[0].id);
    }
  }, [funcionarios, selectedFuncionarioId]);

  const chartData = useMemo(() => {
    const series = isFuncionarioMode
      ? firebaseIsConfigured
        ? buildFuncionarioSeries(real.vendasPorFuncionarioMensal, selectedFuncionarioId)
        : mock.metricSeries[`vendasFuncionario_${selectedFuncionarioId}`] ?? []
      : metricSeries[metricKey] ?? [];
    return buildPeriodSeries(series, period, customRange);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isFuncionarioMode, metricSeries, metricKey, selectedFuncionarioId, period, customRange, real.vendasPorFuncionarioMensal]);

  const headerTitle = isFuncionarioMode
    ? `Por funcionário — ${funcionarios.find((f) => f.id === selectedFuncionarioId)?.nome ?? ''}`
    : activeMetric?.label ?? 'Desempenho';

  return (
    <section className="performance-chart">
      <header className="performance-chart__header">
        <div>
          <span className="performance-chart__eyebrow">Painel principal</span>
          <h2 className="performance-chart__title">{headerTitle}</h2>
        </div>
        <PeriodSelector
          period={period}
          onChangePeriod={setPeriod}
          customRange={customRange}
          onChangeCustomRange={setCustomRange}
        />
      </header>

      {isFuncionarioMode && (
        <div className="performance-chart__funcionarios">
          {funcionarios.map((f) => (
            <button
              key={f.id}
              className={`performance-chart__funcionario-chip ${
                f.id === selectedFuncionarioId ? 'is-active' : ''
              }`}
              onClick={() => setSelectedFuncionarioId(f.id)}
            >
              {f.nome}
            </button>
          ))}
          {funcionarios.length === 0 && (
            <span className="performance-chart__funcionarios-empty">
              Nenhum funcionário cadastrado nesta filial ainda.
            </span>
          )}
        </div>
      )}

      <div className="performance-chart__canvas">
        <ResponsiveContainer width="100%" height="100%">
          {chartType === 'line' ? (
            <LineChart data={chartData} margin={{ top: 8, right: 12, left: -12, bottom: 0 }}>
              <CartesianGrid stroke="rgba(242,233,251,0.06)" vertical={false} />
              <XAxis
                dataKey="date"
                tick={{ fill: 'var(--text-muted)', fontSize: 11 }}
                axisLine={{ stroke: 'rgba(242,233,251,0.12)' }}
                tickLine={false}
                minTickGap={28}
              />
              <YAxis
                tick={{ fill: 'var(--text-muted)', fontSize: 11 }}
                axisLine={false}
                tickLine={false}
                width={64}
                tickFormatter={(v) => compactFormatter.format(v)}
              />
              <Tooltip
                contentStyle={{
                  background: '#1a0c34',
                  border: '1px solid rgba(255,46,156,0.35)',
                  borderRadius: 10,
                  fontSize: 12,
                  color: '#f2e9fb',
                }}
                labelStyle={{ color: '#b39cd4' }}
                itemStyle={{ color: '#f2e9fb' }}
                formatter={(v) => fullCurrencyFormatter.format(v)}
              />
              <Line
                type="monotone"
                dataKey="value"
                stroke="#ff2e9c"
                strokeWidth={2.5}
                dot={false}
                activeDot={{ r: 4 }}
              />
            </LineChart>
          ) : (
            <PieChart>
              <Tooltip
                contentStyle={{
                  background: '#1a0c34',
                  border: '1px solid rgba(255,46,156,0.35)',
                  borderRadius: 10,
                  fontSize: 12,
                  color: '#f2e9fb',
                }}
                labelStyle={{ color: '#f2e9fb' }}
                itemStyle={{ color: '#f2e9fb' }}
                formatter={(v) => fullCurrencyFormatter.format(v)}
              />
              <Legend
                wrapperStyle={{ color: '#f2e9fb', fontSize: 12 }}
                formatter={(value) => <span style={{ color: '#f2e9fb' }}>{value}</span>}
              />
              <Pie
                data={chartData}
                dataKey="value"
                nameKey="date"
                innerRadius="42%"
                outerRadius="72%"
                paddingAngle={2}
              >
                {chartData.map((entry, idx) => (
                  <Cell key={entry.date} fill={PIE_COLORS[idx % PIE_COLORS.length]} />
                ))}
              </Pie>
            </PieChart>
          )}
        </ResponsiveContainer>
        {chartData.length === 0 && (
          <p className="performance-chart__empty">
            Sem dados para este período/métrica ainda.
          </p>
        )}
      </div>

      <footer className="performance-chart__footer">
        <button
          className="performance-chart__type-toggle"
          onClick={() => setChartType((t) => (t === 'line' ? 'pie' : 'line'))}
          title={chartType === 'line' ? 'Ver como gráfico de pizza' : 'Ver como gráfico de linha'}
        >
          {chartType === 'line' ? '◔ Pizza' : '⟋ Linha'}
        </button>

        <MetricSelector groups={metricGroups} activeKey={metricKey} onSelect={setMetricKey} />
      </footer>
    </section>
  );
}
