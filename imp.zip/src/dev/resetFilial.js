import { collection, getDocs, writeBatch } from 'firebase/firestore';
import { db, firebaseIsConfigured } from '../config/firebase.js';

// Coleções que SEMPRE ficam de fora do reset. Se um dia surgir uma coleção
// nova, ela cai automaticamente em RESETAVEIS por engano se alguém só
// copiar/colar — por isso RESETAVEIS é uma lista fechada e explícita, não
// "tudo, exceto...". Adicionar uma coleção nova ao reset é uma decisão que
// precisa ser tomada aqui, de propósito.
const COLECOES_RESETAVEIS = [
  'pendenciasVendas',
  'extratoLancamentos',
  'extratoCartao',
  'baixas',
  'registrosDiarios',
  'registrosMensaisHistoricos',
  'vendasPorFuncionarioMensal',
];

// clientes, vinculosBancarios, funcionarios e adiantamentos NUNCA entram
// aqui. Como o doc de cliente só guarda {nome, origem} — o valor comprado é
// somado na hora a partir de extratoLancamentos/vinculosBancarios/
// pendenciasVendas — resetar as coleções acima já zera o "quanto esse
// cliente comprou" sozinho, sem precisar tocar no cadastro do cliente.

async function apagarColecao(filialId, nomeColecao) {
  const snap = await getDocs(collection(db, 'filiais', filialId, nomeColecao));
  const docs = snap.docs;
  let apagados = 0;
  // Firestore só aceita até 500 operações por batch.
  for (let i = 0; i < docs.length; i += 450) {
    const lote = docs.slice(i, i + 450);
    const batch = writeBatch(db);
    lote.forEach((d) => batch.delete(d.ref));
    await batch.commit();
    apagados += lote.length;
  }
  return apagados;
}

/**
 * Reset controlado de uma filial: apaga só o movimento (vendas, extrato,
 * baixas, agregados de dashboard), preservando clientes, vínculos
 * cliente↔conta, funcionários e adiantamentos.
 *
 * Uso (console do navegador, com o app aberto e logado):
 *   const { resetarDadosDeMovimento } = await import('/src/dev/resetFilial.js');
 *   await resetarDadosDeMovimento('recife-matriz', 'recife-matriz');
 *
 * O segundo argumento é só uma trava de segurança: precisa ser IGUAL ao
 * filialId, digitado por você — não tem como isso disparar sozinho ou por
 * engano.
 */
export async function resetarDadosDeMovimento(filialId, confirmacao) {
  if (!firebaseIsConfigured) {
    throw new Error('Firebase não está configurado nesta sessão — nada foi apagado.');
  }
  if (!filialId || confirmacao !== filialId) {
    throw new Error(
      `Confirmação não bate. Chame de novo passando o filialId exato ("${filialId}") como segundo argumento.`
    );
  }

  const resultado = {};
  for (const nomeColecao of COLECOES_RESETAVEIS) {
    // Sequencial de propósito (não Promise.all): se uma coleção falhar no
    // meio, você sabe exatamente qual já foi apagada e qual não, em vez de
    // um relatório todo-ou-nada.
    resultado[nomeColecao] = await apagarColecao(filialId, nomeColecao);
  }

  console.table(resultado);
  console.log(
    '✅ Reset concluído. Mantidos intactos: clientes, vinculosBancarios, funcionarios, adiantamentos.'
  );
  return resultado;
}
