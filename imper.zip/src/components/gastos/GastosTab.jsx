import { Fragment, useMemo, useRef, useState } from 'react';
import { doc, setDoc } from 'firebase/firestore';
import { db } from '../../config/firebase.js';
import { useFilialCollection } from '../../hooks/useFilialCollection.js';
import { handleEnterNavigation, focusFirstField } from '../../utils/formNav.js';
import { usePdfImport } from '../../hooks/usePdfImport.js';
import { parseDespesasCaixa } from '../../parsers/despesasCaixa.js';
import FirebaseGate from '../layout/FirebaseGate.jsx';
import Combobox from '../common/Combobox.jsx';
import CategoriaGastoPicker from '../common/CategoriaGastoPicker.jsx';
import { CATEGORIAS_GASTO, CAMPO_EXTRA_GASTO } from '../../data/categoriasGasto.js';
import { salvarNaListaAuxiliar } from '../../data/listasAuxiliares.js';
import '../../shared/CrudTab.css';
import '../../shared/PdfImport.css';

export const CATEGORIAS = CATEGORIAS_GASTO;
const CAMPO_EXTRA = CAMPO_EXTRA_GASTO;

export default function GastosTab({ filialId }) {
  return (
    <FirebaseGate>
      <GastosTabInner filialId={filialId} />
    </FirebaseGate>
  );
}

function GastosTabInner({ filialId }) {
  const { items: gastos, add, remove } = useFilialCollection(filialId, 'gastos', 'data');
  const { items: funcionarios } = useFilialCollection(filialId, 'funcionarios', 'nome');
  // Listas auxiliares (distribuidoras, tipos de imposto) ficam em
  // filiais/{id}/listasAuxiliares/{nomeDaLista}, cada uma um doc com um
  // array `valores`. Simples e barato: são listas curtas, lidas junto.
  const { items: listasAux } = useFilialCollection(filialId, 'listasAuxiliares', 'criadoEm');

  const [data, setData] = useState('');
  const [categoria, setCategoria] = useState('');
  const [valor, setValor] = useState('');
  const [descricao, setDescricao] = useState('');
  const [extra, setExtra] = useState('');
  const [extraId, setExtraId] = useState('');
  const [error, setError] = useState(null);
  const formRef = useRef(null);

  const categoriaNormalizada = categoria.trim().toUpperCase();
  const campoExtra = CAMPO_EXTRA[categoriaNormalizada] ?? null;

  const valoresDaLista = useMemo(() => {
    if (campoExtra?.tipo !== 'lista') return [];
    const docLista = listasAux.find((l) => l.id === campoExtra.lista);
    return docLista?.valores ?? [];
  }, [campoExtra, listasAux]);

  const opcoesExtra = useMemo(() => {
    if (!campoExtra) return [];
    if (campoExtra.tipo === 'funcionario') {
      return funcionarios.map((f) => ({ value: f.nome, label: f.nome, id: f.id }));
    }
    return valoresDaLista.map((v) => ({ value: v, label: v }));
  }, [campoExtra, funcionarios, valoresDaLista]);

  function resetForm() {
    setData('');
    setCategoria('');
    setValor('');
    setDescricao('');
    setExtra('');
    setExtraId('');
    // Depois de lançar, o cursor volta pro primeiro campo (data) — o fluxo
    // normal é lançar vários gastos seguidos, então isso poupa um clique a
    // cada lançamento.
    focusFirstField(formRef);
  }

  async function handleAdd(e) {
    e.preventDefault();
    if (!data || !valor) {
      setError('Preencha ao menos a data e o valor.');
      return;
    }
    if (campoExtra && !extra.trim()) {
      setError(`Preencha o campo "${campoExtra.label}" para esta categoria.`);
      return;
    }
    setError(null);
    try {
      const payload = {
        data,
        categoria: categoriaNormalizada || 'GERAL',
        valor: parseFloat(valor) || 0,
        descricao: descricao.trim(),
        origem: 'manual',
      };

      if (campoExtra?.tipo === 'funcionario') {
        // Resolve o ID do funcionário pelo nome digitado (case-insensitive),
        // porque é o ID que amarra o adiantamento à linha certa da tabela de
        // funcionários — guardar só o nome quebraria se ele fosse renomeado.
        const f =
          funcionarios.find((x) => x.id === extraId) ??
          funcionarios.find((x) => x.nome.toLowerCase() === extra.trim().toLowerCase());
        if (!f) {
          setError('Funcionário não encontrado. Escolha um da lista.');
          return;
        }
        payload.funcionarioId = f.id;
        payload.funcionarioNome = f.nome;
      } else if (campoExtra?.tipo === 'lista') {
        const nome = extra.trim();
        payload[campoExtra.lista === 'distribuidoras' ? 'distribuidora' : 'tipoImposto'] = nome;
        await salvarNaListaAuxiliar(filialId, campoExtra.lista, nome);
      }

      await add(payload);
      resetForm();
    } catch (err) {
      setError(err.message);
    }
  }

  function handleRemove(g) {
    const ok = window.confirm(
      `Remover o gasto de R$ ${Number(g.valor).toFixed(2)} (${g.categoria}) do dia ${g.data}?\n\nEsta ação não pode ser desfeita.`
    );
    if (ok) remove(g.id);
  }

  // Gastos agrupados por data — inclusive os que vieram do débito do
  // extrato bancário (origem 'extrato'), que caem na mesma data em que o
  // pagamento saiu da conta. Um caixa de despesas importado pelo parser do
  // CDS e um débito do banco no mesmo dia aparecem juntos, na mesma seção,
  // como uma coisa só: despesa é despesa, não importa de onde ela veio.
  const gruposPorData = useMemo(() => {
    const mapa = new Map();
    gastos.forEach((g) => {
      if (!mapa.has(g.data)) mapa.set(g.data, []);
      mapa.get(g.data).push(g);
    });
    return Array.from(mapa.entries()).sort((a, b) => b[0].localeCompare(a[0]));
  }, [gastos]);

  return (
    <div className="crud-tab">
      <form className="crud-tab__form" onSubmit={handleAdd} ref={formRef}>
        <input
          type="date"
          aria-label="Data do gasto"
          value={data}
          onChange={(e) => setData(e.target.value)}
          onKeyDown={handleEnterNavigation}
        />
        <Combobox
          value={categoria}
          onChange={(v) => {
            setCategoria(v);
            setExtra('');
            setExtraId('');
          }}
          options={CATEGORIAS.map((c) => ({ value: c, label: c }))}
          placeholder="Categoria"
          allowFree={false}
          minWidth={200}
        />
        {campoExtra && (
          <Combobox
            value={extra}
            onChange={(v, option) => {
              setExtra(v);
              setExtraId(option?.id ?? '');
            }}
            options={opcoesExtra}
            placeholder={campoExtra.label}
            allowFree={campoExtra.tipo === 'lista'}
            minWidth={190}
          />
        )}
        <input
          type="number"
          step="0.01"
          placeholder="Valor"
          value={valor}
          onChange={(e) => setValor(e.target.value)}
          onKeyDown={handleEnterNavigation}
        />
        <input
          type="text"
          placeholder="Descrição (opcional)"
          value={descricao}
          onChange={(e) => setDescricao(e.target.value)}
          onKeyDown={handleEnterNavigation}
        />
        <button type="submit">Lançar gasto</button>
      </form>

      {error && <p className="crud-tab__error">{error}</p>}

      <ImportarDespesasCaixa filialId={filialId} funcionarios={funcionarios} />

      <table className="crud-tab__table gastos-table">
        <thead>
          <tr>
            <th>Data</th>
            <th>Categoria</th>
            <th>Referência</th>
            <th>Valor</th>
            <th>Descrição</th>
            <th className="crud-tab__acoes-col" />
          </tr>
        </thead>
        <tbody>
          {gruposPorData.map(([dataGrupo, itens]) => {
            const totalGrupo = itens.reduce((s, g) => s + Number(g.valor || 0), 0);
            return (
              <Fragment key={dataGrupo}>
                <tr className="gastos-table__grupo">
                  <td colSpan={4}>{dataGrupo}</td>
                  <td colSpan={2} className="gastos-table__grupo-total">
                    R$ {totalGrupo.toFixed(2)}
                  </td>
                </tr>
                {itens.map((g) => (
                  <tr key={g.id} className={g.origem === 'extrato' ? 'gastos-table__do-extrato' : ''}>
                    <td />
                    <td>
                      {g.categoria}
                      {g.origem === 'extrato' && (
                        <span className="gastos-table__tag" title="Débito importado do extrato bancário">
                          banco
                        </span>
                      )}
                    </td>
                    <td className="gastos-table__ref">
                      {g.funcionarioNome ?? g.distribuidora ?? g.tipoImposto ?? g.descricao ?? '—'}
                    </td>
                    <td>R$ {Number(g.valor).toFixed(2)}</td>
                    <td>{g.descricao}</td>
                    <td className="crud-tab__acoes-col">
                      <button className="crud-tab__delete" onClick={() => handleRemove(g)}>
                        Remover
                      </button>
                    </td>
                  </tr>
                ))}
              </Fragment>
            );
          })}
          {gastos.length === 0 && (
            <tr>
              <td colSpan={6} className="crud-tab__empty">
                Nenhum gasto lançado ainda.
              </td>
            </tr>
          )}
        </tbody>
      </table>

      <p className="crud-tab__note">
        Distribuidoras (Pedidos) e tipos (Impostos) são salvos automaticamente na primeira vez
        que você digita um nome novo, e passam a aparecer na lista depois disso. Lançamentos de
        "Adiantamento salário" descontam automaticamente do total daquele funcionário na aba
        Funcionários, no mês correspondente. Débitos do extrato bancário (marcados "banco")
        entram aqui sozinhos assim que o extrato é importado — categorize-os pelo botão direito
        na aba Extrato ("Associar Gasto"). Teclado: Enter percorre todos os campos na
        ordem (inclusive os seletores) e envia no último; nos seletores, ↑/↓ abrem e
        percorrem a lista e Enter escolhe e já avança. Depois de lançar, o cursor volta
        sozinho para a data.
      </p>
    </div>
  );
}

// Importa o relatório "Histórico das Despesas" (caixa do dia) do CDS.
// SANGRIA é mostrada só como informação — não é lançada como gasto (é
// dinheiro saindo do caixa físico pra ir pro banco, não um prejuízo).
function ImportarDespesasCaixa({ filialId, funcionarios }) {
  const { texto, nomeArquivo, carregando, erro, handleFile, limpar } = usePdfImport();
  const { add: addGasto } = useFilialCollection(filialId, 'gastos', 'data');
  const [resultado, setResultado] = useState(null);
  const [confirmando, setConfirmando] = useState(false);

  function onFileChange(e) {
    const file = e.target.files?.[0];
    setResultado(null);
    handleFile(file);
    e.target.value = '';
  }

  if (texto && resultado === null) {
    setResultado(parseDespesasCaixa(texto, funcionarios));
  }

  function editarItem(idx, campo, valor) {
    setResultado((r) => {
      const itens = [...r.itens];
      itens[idx] = { ...itens[idx], [campo]: campo === 'valor' ? parseFloat(valor) || 0 : valor };
      return { ...r, itens };
    });
  }

  const itensLancaveis = resultado?.itens.filter((it) => !it.ehSangria) ?? [];
  const sangrias = resultado?.itens.filter((it) => it.ehSangria) ?? [];

  async function confirmar() {
    setConfirmando(true);
    try {
      for (const item of itensLancaveis) {
        // ID determinístico pelo nº de lançamento do CDS: reimportar o mesmo
        // relatório sobrescreve em vez de duplicar o gasto.
        await setDoc(doc(db, 'filiais', filialId, 'gastos', `caixa-despesa_${item.lancamento}`), {
          data: resultado.data,
          categoria: item.categoria,
          valor: item.valor,
          descricao: item.textoOriginal,
          ...(item.funcionarioId
            ? { funcionarioId: item.funcionarioId, funcionarioNome: item.funcionarioNome }
            : {}),
          origem: 'importado-caixa-diario',
        });
      }
      limpar();
      setResultado(null);
    } finally {
      setConfirmando(false);
    }
  }

  function cancelar() {
    limpar();
    setResultado(null);
  }

  return (
    <div className="pdf-import">
      <div className="pdf-import__header">
        <span className="pdf-import__label">Importar despesas do caixa (PDF "Histórico das Despesas"):</span>
        <input type="file" accept="application/pdf" onChange={onFileChange} className="pdf-import__file" />
      </div>

      {carregando && <p className="pdf-import__status">Lendo PDF…</p>}
      {erro && <p className="pdf-import__error">{erro}</p>}

      {resultado && (
        <div className="pdf-import__preview">
          <p className="pdf-import__preview-title">
            {nomeArquivo} — dia {resultado.data ?? '(data não identificada)'}
          </p>

          {sangrias.length > 0 && (
            <p className="pdf-import__status">
              {sangrias.length} sangria(s) identificada(s) somando R${' '}
              {sangrias.reduce((s, x) => s + x.valor, 0).toFixed(2)} — dinheiro que foi pro banco,
              não é gasto, e por isso NÃO será lançado.
            </p>
          )}

          <table className="pdf-import__table pdf-import__table--rows">
            <thead>
              <tr>
                <th>Categoria</th>
                <th>Funcionário</th>
                <th>Valor</th>
              </tr>
            </thead>
            <tbody>
              {itensLancaveis.map((item, idx) => (
                <tr key={item.lancamento}>
                  <td>
                    <Combobox
                      value={item.categoria}
                      onChange={(v) => editarItem(idx, 'categoria', v)}
                      options={CATEGORIAS_GASTO.map((c) => ({ value: c, label: c }))}
                      allowFree={false}
                      minWidth={160}
                    />
                  </td>
                  <td className={item.funcionarioNome ? '' : 'pdf-import__unmatched'}>
                    {item.funcionarioNome ?? '(nenhum vínculo encontrado)'}
                  </td>
                  <td>
                    <input
                      type="number"
                      step="0.01"
                      value={item.valor}
                      onChange={(e) => editarItem(idx, 'valor', e.target.value)}
                    />
                  </td>
                </tr>
              ))}
              {itensLancaveis.length === 0 && (
                <tr>
                  <td colSpan={3}>Nenhuma despesa lançável identificada nesse PDF.</td>
                </tr>
              )}
            </tbody>
          </table>

          <div className="pdf-import__actions">
            <button
              className="pdf-import__confirm"
              onClick={confirmar}
              disabled={confirmando || itensLancaveis.length === 0 || !resultado.data}
            >
              {confirmando ? 'Salvando…' : 'Confirmar e lançar'}
            </button>
            <button className="pdf-import__cancel" onClick={cancelar}>
              Cancelar
            </button>
          </div>
          {!resultado.data && (
            <p className="pdf-import__error">
              Não consegui identificar a data no relatório — confirme que é mesmo um "Histórico
              das Despesas" exportado do CDS.
            </p>
          )}
        </div>
      )}
    </div>
  );
}
