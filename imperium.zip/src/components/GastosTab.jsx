import { useState } from 'react';
import { useFilialCollection } from '../hooks/useFilialCollection.js';
import { handleEnterNavigation } from '../utils/formNav.js';
import FirebaseGate from './FirebaseGate.jsx';
import './CrudTab.css';

export default function GastosTab({ filialId }) {
  return (
    <FirebaseGate>
      <GastosTabInner filialId={filialId} />
    </FirebaseGate>
  );
}

function GastosTabInner({ filialId }) {
  const { items: gastos, add, remove } = useFilialCollection(filialId, 'gastos', 'data');
  const [data, setData] = useState('');
  const [categoria, setCategoria] = useState('');
  const [valor, setValor] = useState('');
  const [descricao, setDescricao] = useState('');
  const [error, setError] = useState(null);

  async function handleAdd(e) {
    e.preventDefault();
    if (!data || !valor) return;
    setError(null);
    try {
      await add({
        data,
        categoria: categoria.trim() || 'Geral',
        valor: parseFloat(valor) || 0,
        descricao: descricao.trim(),
        origem: 'manual',
      });
      setData('');
      setCategoria('');
      setValor('');
      setDescricao('');
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div className="crud-tab">
      <form className="crud-tab__form" onSubmit={handleAdd}>
        <input type="date" value={data} onChange={(e) => setData(e.target.value)} onKeyDown={handleEnterNavigation} />
        <input
          type="text"
          placeholder="Categoria"
          value={categoria}
          onChange={(e) => setCategoria(e.target.value)}
          onKeyDown={handleEnterNavigation}
        />
        <input
          type="number"
          step="0.01"
          placeholder="Valor"
          value={valor}
          onChange={(e) => setValor(e.target.value)}
          onKeyDown={handleEnterNavigation}
        />
        <input
          type="text"
          placeholder="Descrição (opcional)"
          value={descricao}
          onChange={(e) => setDescricao(e.target.value)}
          onKeyDown={handleEnterNavigation}
        />
        <button type="submit">Lançar gasto</button>
      </form>

      {error && <p className="crud-tab__error">{error}</p>}

      <table className="crud-tab__table">
        <thead>
          <tr>
            <th>Data</th>
            <th>Categoria</th>
            <th>Valor</th>
            <th>Descrição</th>
            <th />
          </tr>
        </thead>
        <tbody>
          {gastos.map((g) => (
            <tr key={g.id}>
              <td>{g.data}</td>
              <td>{g.categoria}</td>
              <td>R$ {Number(g.valor).toFixed(2)}</td>
              <td>{g.descricao}</td>
              <td>
                <button className="crud-tab__delete" onClick={() => remove(g.id)}>
                  Remover
                </button>
              </td>
            </tr>
          ))}
          {gastos.length === 0 && (
            <tr>
              <td colSpan={5} className="crud-tab__empty">
                Nenhum gasto lançado ainda.
              </td>
            </tr>
          )}
        </tbody>
      </table>

      <p className="crud-tab__note">
        Estes são gastos avulsos lançados manualmente. Despesas que já vêm dentro do caixa
        diário importado por IA (campo <code>caixa.despesas</code>) ficam em
        <code>registrosDiarios</code> e ainda não são somadas aqui — isso entra quando
        montarmos o cálculo real de Lucro.
      </p>
    </div>
  );
}
