// Prompt + schema para o tipo "funcionario-mensal": um relatório mensal de
// vendas por vendedor/funcionário.

export const promptFuncionarioMensal = `Você é um extrator de dados financeiros. Vai
receber um relatório mostrando o TOTAL DE VENDAS de cada FUNCIONÁRIO/VENDEDOR em um
determinado MÊS de uma loja de varejo.

Extraia o mês/ano do relatório (formato YYYY-MM) e uma lista com o nome de cada
funcionário e o total vendido por ele naquele mês. Use o nome exatamente como
aparece no documento. Números devem ser extraídos exatamente como aparecem (remova
"R$", troque vírgula decimal por ponto). Não invente funcionários que não estejam no
documento.

Responda SOMENTE com o JSON no formato do schema fornecido, nada além disso.`;

export const schemaFuncionarioMensal = {
  type: 'object',
  properties: {
    mes: { type: 'string', description: 'Formato YYYY-MM' },
    funcionarios: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          nome: { type: 'string' },
          totalVendido: { type: 'number' },
        },
        required: ['nome', 'totalVendido'],
      },
    },
  },
  required: ['mes', 'funcionarios'],
};
