import { useState } from 'react';
import { useFilialCollection } from '../hooks/useFilialCollection.js';
import { handleEnterNavigation } from '../utils/formNav.js';
import FirebaseGate from './FirebaseGate.jsx';
import './CrudTab.css';

export default function FuncionariosTab({ filialId }) {
  return (
    <FirebaseGate>
      <FuncionariosTabInner filialId={filialId} />
    </FirebaseGate>
  );
}

function FuncionariosTabInner({ filialId }) {
  const { items: funcionarios, add, update, remove } = useFilialCollection(
    filialId,
    'funcionarios',
    'nome'
  );
  const [nome, setNome] = useState('');
  const [comissao, setComissao] = useState('');
  const [error, setError] = useState(null);

  async function handleAdd(e) {
    e.preventDefault();
    if (!nome.trim()) return;
    setError(null);
    try {
      await add({
        nome: nome.trim(),
        comissaoPercentual: parseFloat(comissao) || 0,
        ativo: true,
      });
      setNome('');
      setComissao('');
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div className="crud-tab">
      <form className="crud-tab__form" onSubmit={handleAdd}>
        <input
          type="text"
          placeholder="Nome do funcionário"
          value={nome}
          onChange={(e) => setNome(e.target.value)}
          onKeyDown={handleEnterNavigation}
        />
        <input
          type="number"
          step="0.1"
          placeholder="% comissão"
          value={comissao}
          onChange={(e) => setComissao(e.target.value)}
          onKeyDown={handleEnterNavigation}
        />
        <button type="submit">Adicionar</button>
      </form>

      {error && <p className="crud-tab__error">{error}</p>}

      <table className="crud-tab__table">
        <thead>
          <tr>
            <th>Nome</th>
            <th>Comissão</th>
            <th>Ativo</th>
            <th />
          </tr>
        </thead>
        <tbody>
          {funcionarios.map((f) => (
            <tr key={f.id}>
              <td>{f.nome}</td>
              <td>{f.comissaoPercentual}%</td>
              <td>
                <button
                  className="crud-tab__toggle"
                  onClick={() => update(f.id, { ativo: !f.ativo })}
                >
                  {f.ativo ? 'Ativo' : 'Inativo'}
                </button>
              </td>
              <td>
                <button className="crud-tab__delete" onClick={() => remove(f.id)}>
                  Remover
                </button>
              </td>
            </tr>
          ))}
          {funcionarios.length === 0 && (
            <tr>
              <td colSpan={4} className="crud-tab__empty">
                Nenhum funcionário cadastrado ainda.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
